#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./setup_and_push.sh --llm-key "YOUR_LLM_KEY" [--github-create owner/repo] [--push]
#
# This script safely injects your LLM key locally and optionally creates a GitHub repo.
# It never uploads your token anywhere except when using 'gh' CLI on your authenticated account.

show_usage() {
  echo "Usage: $0 --llm-key "YOUR_LLM_KEY" [--github-create owner/repo] [--push]"
  exit 1
}

LLM_KEY=""
GITHUB_REPO=""
DO_PUSH=0

while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    --llm-key)
      LLM_KEY="$2"; shift 2;;
    --github-create)
      GITHUB_REPO="$2"; shift 2;;
    --push)
      DO_PUSH=1; shift;;
    *)
      echo "Unknown arg: $1"; show_usage;;
  esac
done

if [[ -z "$LLM_KEY" ]]; then
  echo "Error: --llm-key is required"
  show_usage
fi

mkdir -p infra backend

# Create or update infra/.env
cat > infra/.env <<EOF
JWT_SECRET=$(openssl rand -hex 16)
DATABASE_URL=sqlite:///./civiclens.db
LLM_PROVIDER=openai
OPENAI_API_KEY=${LLM_KEY}
OPENAI_MODEL=gpt-4o-mini
EOF

# Create or update backend/.env
cat > backend/.env <<EOF
JWT_SECRET=$(openssl rand -hex 16)
DATABASE_URL=sqlite:///./civiclens.db
LLM_PROVIDER=openai
OPENAI_API_KEY=${LLM_KEY}
OPENAI_MODEL=gpt-4o-mini
EOF

echo "Local env files configured."

if [[ -n "$GITHUB_REPO" ]]; then
  if ! command -v gh >/dev/null 2>&1; then
    echo "'gh' CLI not found. Install from https://cli.github.com/ and run 'gh auth login' first."
    exit 1
  fi
  gh repo create "${GITHUB_REPO}" --public --source=. --remote=origin --push
fi

if [[ $DO_PUSH -eq 1 && -n "$GITHUB_REPO" ]]; then
  git add .
  git commit -m "Add local setup and environment configuration"
  git push origin main
fi

echo "✅ CivicLens setup complete. Start with: docker compose up --build"
